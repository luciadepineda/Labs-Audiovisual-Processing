function [XCorr,Lag]=IPALab2_XCorr(SP,LagMax)

if (min(size(SP))==1) %if SP is a vector set SP a row vector
    SP=SP(:)';
end
XCorr=zeros(1,2*LagMax+1);
for kk=1:size(SP,1)
    XCorr=XCorr+xcorr(SP(kk,:),LagMax);
end
XCorr=(XCorr/size(SP,1))/size(SP,2);
Lag=[-LagMax:LagMax];